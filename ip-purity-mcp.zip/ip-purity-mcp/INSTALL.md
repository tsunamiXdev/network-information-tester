# Install in DeepSeek Harness

Extract the ZIP to a permanent, writable folder on the computer where you will open the browser. Requires Python 3.9 or later. The browser app is prebuilt.

In the active Harness profile’s MCP settings, add one server named `ip-purity-check`. Choose `stdio`, set the command to the absolute path of Python 3, and enter two separate arguments:

1. `-I`
2. The absolute path to `app/mcp_server.py` inside the extracted folder.

Enable the server and verify that `get_check_url` and `read_latest_profile` appear. Call `get_check_url` and open the link in the browser profile you want to measure. Enter a name and select **Start check**. The page contacts external diagnostic services. When it shows **Saved to …**, call `read_latest_profile` to return the newest snapshot to DeepSeek. Check its `profileName` and `observedAt` to identify the run.

For a standalone check on macOS, double-click `Start.command`. By default, snapshots go in `output/` beside the launcher. To choose another folder, pass the same optional argument to both MCP tools, for example `{"output_dir": "/absolute/path/to/snapshots"}`. The MCP server creates the requested folder when starting the check. The browser shows the full saved path, and the read tool returns it as `snapshotPath`.
