"""Serve the built browser app and store completed profiles outside the web root."""
from html import escape
import json
import os
import tempfile
import webbrowser
from datetime import datetime, timezone
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from uuid import uuid4

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / "output"


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, output=OUTPUT, **kwargs):
        self.output = output
        super().__init__(*args, **kwargs)

    def do_GET(self):
        if self.path.split("?", 1)[0] != "/":
            return super().do_GET()
        page = (ROOT / "profile.html").read_text(encoding="utf-8").replace("{{folder}}", escape(str(self.output))).encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

    def do_POST(self):
        if self.path != "/api/profile":
            return self.send_error(404)
        host = f"127.0.0.1:{self.server.server_port}"
        if self.headers.get("Host") != host or self.headers.get("Origin") != f"http://{host}":
            return self.send_error(403)
        if self.headers.get_content_type() != "application/json":
            return self.send_error(415)
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= 2_000_000:
                return self.send_error(413)
            profile = json.loads(self.rfile.read(size))
            if not isinstance(profile, dict) or profile.get("observer") != "browser" or profile.get("schemaVersion") not in (1, 2):
                return self.send_error(400)
            payload = json.dumps(profile, indent=2, ensure_ascii=False, allow_nan=False).encode() + b"\n"
        except (ValueError, RecursionError):
            return self.send_error(400)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        name = f"profile-{stamp}-{uuid4().hex}.json"
        try:
            self.output.mkdir(mode=0o700, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=self.output, delete=False) as temp:
                try:
                    temp.write(payload)
                    temp.flush()
                    os.replace(temp.name, self.output / name)
                finally:
                    Path(temp.name).unlink(missing_ok=True)
        except OSError:
            return self.send_error(500, "Unable to save profile")
        response = json.dumps({"file": name, "snapshotPath": str(self.output / name)}).encode()
        self.send_response(201)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)


if __name__ == "__main__":
    handler = partial(Handler, directory=str(ROOT / "dist"))
    with ThreadingHTTPServer(("127.0.0.1", 0), handler) as server:
        url = f"http://127.0.0.1:{server.server_port}/"
        print(f"Open {url} in the browser profile to test. Press Control-C to stop.", flush=True)
        webbrowser.open(url)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
