"""Local MCP stdio interface to the compact browser network profile."""
import json
import sys
from functools import partial
from pathlib import Path
from threading import Thread
from http.server import ThreadingHTTPServer

# Allow isolated Python (-I) to load only this adapter's sibling module.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from profile_server import Handler, ROOT, OUTPUT

VERSION = "2025-06-18"
TOOLS = {
    "get_check_url": "Get the local check URL. Open it in the intended browser profile on this computer to run a fresh check. Enter a profile name and start the check to contact external diagnostic services.",
    "read_latest_profile": "Read the newest completed compact v2 snapshot in the selected snapshot folder, including its observation time. May predate your current check.",
}
servers = {}


def call_tool(name, output):
    if name == "get_check_url":
        if output not in servers:
            output.mkdir(mode=0o700, parents=True, exist_ok=True)
            handler = partial(Handler, output=output, directory=str(ROOT / "dist"))
            server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
            Thread(target=server.serve_forever, daemon=True).start()
            servers[output] = server
        return {"url": f"http://127.0.0.1:{servers[output].server_port}/", "output_dir": str(output)}
    for path in sorted(output.glob("profile-*.json"), key=lambda p: p.stat().st_mtime_ns, reverse=True):
        if path.is_symlink():
            continue
        profile = json.loads(path.read_bytes())
        if isinstance(profile, dict) and profile.get("schemaVersion") == 2 and profile.get("observer") == "browser":
            return {**profile, "snapshotPath": str(path)}
    return {"status": "no_completed_v2_profile"}


def dispatch(method, params):
    if method == "initialize":
        return {"protocolVersion": VERSION, "serverInfo": {"name": "ip-purity-check", "version": "1.2.0"},
                "capabilities": {"tools": {}}}
    if method == "ping":
        return {}
    if method == "tools/list":
        schema = {"type": "object", "properties": {"output_dir": {
            "type": "string", "minLength": 1,
            "description": "Absolute folder on the MCP host for snapshots. Defaults to output beside Start.command. Use the same folder for saving and reading."}}, "additionalProperties": False}
        return {"tools": [{"name": name, "description": desc, "inputSchema": schema} for name, desc in TOOLS.items()]}
    if method == "tools/call":
        name = params.get("name")
        args = params.get("arguments", {})
        if name not in TOOLS or not isinstance(args, dict) or args.keys() - {"output_dir"}:
            raise ValueError("Unknown tool or unexpected arguments")
        folder = args.get("output_dir", str(OUTPUT))
        if not isinstance(folder, str) or not Path(folder).is_absolute():
            raise ValueError("output_dir must be an absolute directory path")
        try:
            output = Path(folder).resolve()
            if output.is_relative_to((ROOT / "dist").resolve()):
                raise ValueError("Choose a snapshot folder outside the served browser files")
            result = call_tool(name, output)
        except (OSError, ValueError):
            return {"isError": True, "content": [{"type": "text", "text": "Local profile or server unavailable."}]}
        return {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}]}
    raise KeyError(method)


def main():
    for line in sys.stdin:
        reply = {"jsonrpc": "2.0", "id": None}
        try:
            req = json.loads(line)
            if not isinstance(req, dict) or req.get("jsonrpc") != "2.0" or not isinstance(req.get("method"), str):
                raise ValueError("Invalid JSON-RPC request")
            if "id" not in req:
                continue
            reply["id"] = req["id"]
            params = req.get("params", {})
            if not isinstance(params, dict):
                raise TypeError("Expected an object")
            reply["result"] = dispatch(req["method"], params)
        except json.JSONDecodeError:
            reply["error"] = {"code": -32700, "message": "Parse error"}
        except KeyError:
            reply["error"] = {"code": -32601, "message": "Method not found"}
        except (TypeError, ValueError) as error:
            reply["error"] = {"code": -32602, "message": str(error)}
        print(json.dumps(reply, ensure_ascii=True), flush=True)


if __name__ == "__main__":
    try:
        main()
    finally:
        for server in servers.values():
            server.shutdown()
            server.server_close()
