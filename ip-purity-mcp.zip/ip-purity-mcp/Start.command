#!/bin/zsh
set -eu
cd -- "${0:A:h}"
if [[ ! -f app/dist/index.html ]]; then
  print 'The browser app has not been built. No server was started.'
  exit 1
fi
exec /usr/bin/python3 -I app/profile_server.py
